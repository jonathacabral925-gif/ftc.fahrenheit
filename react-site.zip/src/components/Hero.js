import React from 'react';

function Hero() {
  return (
    <section style={{ padding: '50px', textAlign: 'center' }}>
      <h1>Bem-vindo ao Meu Site React!</h1>
      <p>Deploy fácil no GitHub + Vercel 🚀</p>
    </section>
  );
}

export default Hero;