import React from 'react';

function Navbar() {
  return (
    <nav style={{ background: '#333', padding: '10px', color: 'white' }}>
      <h1>Meu Site</h1>
    </nav>
  );
}

export default Navbar;