import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';

function App() {
  return (
    <div>
      <Navbar />
      <Hero />
      <h2>Seção Exemplo</h2>
      <p>Esse é o seu site React rodando no GitHub + Vercel!</p>
    </div>
  );
}

export default App;